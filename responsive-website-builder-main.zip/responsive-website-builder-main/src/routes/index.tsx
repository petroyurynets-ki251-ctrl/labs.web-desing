import { createFileRoute } from "@tanstack/react-router";
import { Shield, Lock, Mail, Phone, MapPin, User, FileText, Search, BarChart3, Check, Menu, X, Twitter, Linkedin, Github } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "IdentityHub — Protect Your Privacy Online" },
      { name: "description", content: "Remove your personal information from the internet and protect your identity with IdentityHub." },
    ],
  }),
  component: Index,
});

function Nav() {
  const [open, setOpen] = useState(false);
  const links = ["How it works", "Pricing", "Features", "Reviews", "About us"];
  return (
    <header className="absolute top-0 left-0 right-0 z-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-5 flex items-center justify-between">
        <div className="flex items-center gap-2 font-semibold text-foreground">
          <Shield className="h-5 w-5 text-primary" />
          <span>IdentityHub</span>
        </div>
        <nav className="hidden md:flex items-center gap-7 text-sm text-muted-foreground">
          {links.map(l => <a key={l} href="#" className="hover:text-foreground transition">{l}</a>)}
        </nav>
        <a href="#pricing" className="hidden md:inline-flex items-center rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 transition">
          Start free trial
        </a>
        <button className="md:hidden text-foreground" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>
      {open && (
        <div className="md:hidden bg-card border-t border-border px-4 py-4 space-y-3">
          {links.map(l => <a key={l} href="#" className="block text-sm text-muted-foreground">{l}</a>)}
          <a href="#pricing" className="block rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground text-center">Start free trial</a>
        </div>
      )}
    </header>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden pt-32 pb-20 sm:pt-40 sm:pb-28">
      <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight">
            <span className="bg-clip-text text-transparent" style={{ backgroundImage: "var(--gradient-text)" }}>Protect</span>{" "}
            <span className="text-foreground">your</span>
            <br />
            <span className="text-foreground">privacy online</span>
          </h1>
          <p className="mt-6 text-muted-foreground max-w-md">
            IdentityHub removes a lot of personal info you may have shared, from data brokers that resell it to anyone — and keeps your digital footprint, biography, and personal data clean.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#pricing" className="rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground hover:opacity-90 transition">Start free trial</a>
            <a href="#features" className="rounded-full border border-border px-6 py-3 text-sm font-medium text-foreground hover:bg-card transition">Learn more</a>
          </div>
        </div>
        <div className="relative flex justify-center lg:justify-end">
          <div className="relative w-64 h-64 sm:w-80 sm:h-80">
            <div className="absolute inset-0 rounded-full blur-3xl opacity-60" style={{ background: "radial-gradient(circle, oklch(0.55 0.25 260), transparent 70%)" }} />
            <div className="relative w-full h-full rounded-full bg-gradient-to-br from-accent to-card border border-border flex items-center justify-center">
              <Lock className="h-24 w-24 text-foreground" />
            </div>
            <div className="absolute -top-4 -left-8 bg-card border border-border rounded-xl px-4 py-3 text-xs flex items-center gap-2 shadow-xl">
              <div className="h-2 w-2 rounded-full bg-primary" />
              <div>
                <div className="text-muted-foreground">Personal info</div>
                <div className="text-foreground font-medium">100% protected</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function FeatureRow({ title, text, reverse, mock }: { title: string; text: string; reverse?: boolean; mock: React.ReactNode }) {
  return (
    <section className="py-16 sm:py-24">
      <div className={`mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center ${reverse ? "lg:[&>*:first-child]:order-2" : ""}`}>
        <div>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground">{title}</h2>
          <p className="mt-5 text-muted-foreground max-w-md">{text}</p>
        </div>
        <div>{mock}</div>
      </div>
    </section>
  );
}

function MockCard() {
  return (
    <div className="relative bg-card border border-border rounded-2xl p-5 shadow-2xl">
      <div className="flex items-start gap-3">
        <div className="h-10 w-10 rounded-lg bg-accent/20 flex items-center justify-center"><Mail className="h-5 w-5 text-accent" /></div>
        <div className="flex-1 space-y-2">
          <div className="h-2 bg-muted rounded w-3/4" />
          <div className="h-2 bg-muted rounded w-1/2" />
        </div>
      </div>
      <div className="mt-4 flex items-center justify-between">
        <button className="rounded-full bg-primary text-primary-foreground text-xs px-3 py-1.5">Remove</button>
        <Lock className="h-4 w-4 text-muted-foreground" />
      </div>
    </div>
  );
}

function InfoGrid() {
  const items = [
    { icon: User, label: "Username", val: "+1 (555) 432-1234" },
    { icon: Phone, label: "Phone number", val: "+1 (555) 432-1234" },
    { icon: Mail, label: "Email address", val: "+1 (555) 432-1234" },
    { icon: MapPin, label: "Home address", val: "+1 (555) 432-1234" },
    { icon: FileText, label: "Passport", val: "AS1245-103" },
    { icon: FileText, label: "Driver's license", val: "AS1245-103" },
  ];
  return (
    <div className="grid grid-cols-2 gap-3">
      {items.map(i => (
        <div key={i.label} className="bg-card border border-border rounded-xl p-4">
          <i.icon className="h-4 w-4 text-primary" />
          <div className="mt-2 text-xs text-muted-foreground">{i.label}</div>
          <div className="text-sm text-foreground font-medium truncate">{i.val}</div>
        </div>
      ))}
    </div>
  );
}

function WhyChoose() {
  const items = [
    { icon: User, title: "Personal information removal", text: "Our service automatically scans data brokers, people-finder sites and other databases to remove your personal information." },
    { icon: Shield, title: "Cloaking alias profiles", text: "We'll create regular aliases on your behalf, which include believable but artificial names, emails, and other personal info." },
    { icon: BarChart3, title: "Detailed Reporting", text: "You'll receive regular reports on your subscriptions and how it's affecting threats. Know what's been removed and what's still in progress." },
  ];
  return (
    <section id="features" className="py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground">Why choose us</h2>
          <p className="mt-3 text-muted-foreground text-sm">We are the #1 privacy service. Look at the benefits we offer.</p>
        </div>
        <div className="mt-12 grid md:grid-cols-2 gap-5">
          {items.slice(0,2).map(i => <FeatureCard key={i.title} {...i} />)}
          <div className="md:col-span-2"><FeatureCard {...items[2]} /></div>
        </div>
      </div>
    </section>
  );
}

function FeatureCard({ icon: Icon, title, text }: { icon: any; title: string; text: string }) {
  return (
    <div className="bg-card border border-border rounded-2xl p-6 sm:p-8 grid sm:grid-cols-2 gap-6 items-center">
      <div>
        <h3 className="text-lg font-semibold text-foreground">{title}</h3>
        <p className="mt-2 text-sm text-muted-foreground">{text}</p>
      </div>
      <div className="bg-background/50 border border-border rounded-xl p-4 flex items-center gap-3">
        <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center"><Icon className="h-5 w-5 text-primary" /></div>
        <div className="flex-1 space-y-2">
          <div className="h-2 bg-muted rounded w-3/4" />
          <div className="h-2 bg-muted rounded w-1/2" />
        </div>
      </div>
    </div>
  );
}

function Reviews() {
  const reviews = [
    "Cameron Williamson", "Leslie Alexander", "Guy Hawkins", "Brooklyn Simmons",
    "Daniel Stewart", "Floyd Miles", "Savannah Nguyen", "Cody Fisher",
  ];
  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground">The word on IdentityHub</h2>
          <p className="mt-3 text-muted-foreground text-sm">People are saying nice things about us. Read what real customers think about how IdentityHub keeps them safe online.</p>
        </div>
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {reviews.map(name => (
            <div key={name} className="bg-card border border-border rounded-2xl p-5">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-muted" />
                <div className="text-sm font-medium text-foreground">{name}</div>
              </div>
              <p className="mt-4 text-xs text-muted-foreground leading-relaxed">
                They removed my data within weeks. The dashboard is clean and reporting helps me sleep at night. Disposable email aliases are a brilliant touch.
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  const plans = [
    { name: "Start free", price: "$0", popular: false, features: ["Type of email", "Online presence", "Access to all modules", "Accessibility", "Catalog weekly websites", "Search via newsletter"] },
    { name: "Single", price: "$56", popular: true, features: ["Type of email", "Online presence", "Access to all modules", "Accessibility", "Catalog weekly websites", "Search via newsletter"] },
    { name: "Family", price: "$124", popular: false, features: ["Type of email", "Online presence", "Access to all modules", "Accessibility", "Catalog weekly websites", "Search via newsletter"] },
  ];
  return (
    <section id="pricing" className="py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground">Pricing</h2>
          <p className="mt-3 text-muted-foreground text-sm">Pick a plan that fits your needs and try IdentityHub for free.</p>
          <div className="mt-6 inline-flex rounded-full bg-card border border-border p-1 text-xs">
            <button className="rounded-full bg-primary text-primary-foreground px-4 py-1.5">Monthly -10%</button>
            <button className="px-4 py-1.5 text-muted-foreground">Yearly</button>
          </div>
        </div>
        <div className="mt-12 grid md:grid-cols-3 gap-5">
          {plans.map(p => (
            <div key={p.name} className={`rounded-2xl p-6 border ${p.popular ? "border-primary bg-card" : "border-border bg-card"}`} style={p.popular ? { background: "linear-gradient(180deg, oklch(0.25 0.08 350), oklch(0.18 0.028 270))" } : {}}>
              <div className="text-xs text-muted-foreground">{p.name}</div>
              <div className="mt-3 text-4xl font-bold text-foreground">{p.price}</div>
              <div className="text-xs text-muted-foreground">Per month</div>
              <ul className="mt-6 space-y-3">
                {p.features.map(f => (
                  <li key={f} className="flex items-center gap-2 text-sm text-foreground">
                    <Check className="h-4 w-4 text-primary" /> {f}
                  </li>
                ))}
              </ul>
              <button className={`mt-6 w-full rounded-full py-2.5 text-sm font-medium ${p.popular ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"}`}>Request access</button>
              <p className="mt-3 text-center text-xs text-muted-foreground">{p.popular ? "Save $20 per year" : "Try free, no risk"}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-8 text-sm">
        <div className="flex items-center gap-2 font-semibold text-foreground">
          <Shield className="h-5 w-5 text-primary" /> IdentityHub
        </div>
        <div>
          <div className="text-foreground font-medium mb-3">It's free to try out</div>
          <ul className="space-y-2 text-muted-foreground">
            <li>Pricing</li><li>Features</li><li>FAQ</li>
          </ul>
        </div>
        <div>
          <div className="text-foreground font-medium mb-3">Company</div>
          <ul className="space-y-2 text-muted-foreground">
            <li>Our company</li><li>Benefits</li><li>Blog</li>
          </ul>
        </div>
        <div>
          <div className="text-foreground font-medium mb-3">Legal</div>
          <ul className="space-y-2 text-muted-foreground">
            <li>Privacy policy</li><li>Terms of service</li><li>Permitted use policy</li>
          </ul>
        </div>
      </div>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-10 flex flex-wrap items-center justify-between gap-4 text-xs text-muted-foreground">
        <div className="flex gap-4">
          <span className="flex items-center gap-1"><Github className="h-3 w-3" />Company</span>
          <span className="flex items-center gap-1"><Twitter className="h-3 w-3" />Twitter</span>
          <span className="flex items-center gap-1"><Linkedin className="h-3 w-3" />LinkedIn</span>
        </div>
        <div>© 2026 IdentityHub</div>
      </div>
    </footer>
  );
}

function Index() {
  return (
    <main className="min-h-screen bg-background">
      <Nav />
      <Hero />
      <FeatureRow
        title="We remove your private information from the online"
        text="Requesting that you give some of your personal data to brokers is a sure way to lose a lot of trust every year. They take a lot of personal information off the internet to help you avoid that. We're constantly removing your data."
        mock={<MockCard />}
      />
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center">
          <InfoGrid />
          <div>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground">Cloaking identities stand in for your personal data</h2>
            <p className="mt-5 text-muted-foreground max-w-md">Forget about spam, unsolicited offers, and tracking attempts. Step into your new digital identity — fully cloaked, verified, and ready to use anywhere.</p>
          </div>
        </div>
      </section>
      <FeatureRow
        title="Dedicated Support"
        text="A dedicated team is on hand to answer questions, help with onboarding, and make sure our online identity protection service is doing exactly what you need it to do. Available 24/7."
        mock={<MockCard />}
      />
      <WhyChoose />
      <Reviews />
      <Pricing />
      <Footer />
    </main>
  );
}
